package lk.ijse.gdse66.helloshoes.repository;

import lk.ijse.gdse66.helloshoes.entity.AdminPanel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AdminPanelRepo extends JpaRepository<AdminPanel,String> {
}
