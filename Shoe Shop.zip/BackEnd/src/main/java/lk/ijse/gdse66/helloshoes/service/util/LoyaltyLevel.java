package lk.ijse.gdse66.helloshoes.service.util;

public enum LoyaltyLevel {
    GOLD, SILVER, BRONZE, NEW
}
