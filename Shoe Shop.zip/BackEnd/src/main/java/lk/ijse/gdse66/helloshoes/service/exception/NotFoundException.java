package lk.ijse.gdse66.helloshoes.service.exception;

public class NotFoundException extends ServiceException{
    public NotFoundException(String message) {
        super(message);
    }
}
