package lk.ijse.gdse66.helloshoes.service.util;

public enum Role {
    ADMIN,USER
}
