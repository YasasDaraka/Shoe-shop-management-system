package lk.ijse.gdse66.helloshoes.service.exception;

public class DuplicateRecordException extends ServiceException{
    public DuplicateRecordException(String message) {
        super(message);
    }
}
