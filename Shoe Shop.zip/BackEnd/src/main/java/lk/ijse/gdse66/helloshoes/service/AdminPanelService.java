package lk.ijse.gdse66.helloshoes.service;

public interface AdminPanelService {
}
