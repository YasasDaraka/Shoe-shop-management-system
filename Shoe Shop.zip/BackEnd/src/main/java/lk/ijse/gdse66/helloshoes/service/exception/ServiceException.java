package lk.ijse.gdse66.helloshoes.service.exception;

public class ServiceException extends RuntimeException{
    public ServiceException(String message) {
        super(message);
    }
}
