let btnDashboard = $('#btnDashboard');
let btnCustomer = $('#btnCustomer');
let btnInventory = $('#btnInventory');
let btnSupplier = $('#btnSupplier');
let btnEmployee = $('#btnEmployee');
let btnSales = $('#btnSales');
let btnAdmin = $('#btnAdminPanel');
let btnUser = $('#btnUsers');

let btnAllCus = $('#getAllCus');
let btnAllItm = $('#getAllItm');
let btnAllEmp = $('#getAllEmp');
let btnAllSup = $('#getAllSup');

let btnBackCus = $('#backCus');
let btnBackItm = $('#backItm');
let btnBackEmp = $('#backEmp');
let btnBackSup = $('#backSup');

let empList = $('#employee-list');
let supList = $('#supplier-list');
let itmList = $('#inventory-list');
let cusList = $('#customer-list');

let empMain = $('#employee-main');
let supMain = $('#supplier-main');
let itmMain = $('#inventory-main');
let cusMain = $('#customer-main');


function hideAdminPages(){
    customerPage.css('display','none');
    employeePage.css('display','none');
    supplierPage.css('display','none');
    inventoryPage.css('display','none');
    paymentPage.css('display','none');
    adminEditPage.css('display','none');
    userEditPage.css('display','none');
    $("#formIcon").text("");
}
function hideMainPages(){
    empMain.css('display','none');
    supMain.css('display','none');
    itmMain.css('display','none');
    cusMain.css('display','none');
}
function hideAllLoadPages(){
    empList.css('display','none');
    supList.css('display','none');
    itmList.css('display','none');
    cusList.css('display','none');
}

$("#getAllCus, #getAllItm, #getAllEmp, #getAllSup").click(function () {
    hideMainPages();
    switch ($(this).attr('id')) {
        case 'getAllCus':
            cusList.css('display', 'block');
            getAllCustomers();
            break;
        case 'getAllItm':
            itmList.css('display', 'block');
            getAllItems("/getAll");
            break;
        case 'getAllEmp':
            empList.css('display', 'block');
            getAllEmployees();
            break;
        case 'getAllSup':
            supList.css('display', 'block');
            getAllSuppliers();
            break;
    }
});
$("#btnCustomer, #btnInventory, #btnSupplier, #btnEmployee, #btnSales,#btnAdminPanel,#btnUsers,#btnDashboard").click(function () {
    hideAdminPages();
    switch ($(this).attr('id')) {
        case 'btnCustomer':
            $("#formIcon").text("Customer page");
            cusList.css('display', 'none');
            cusMain.css('display', 'block');
            customerPage.css('display', 'block');
            allCaptureClear();
            break;
        case 'btnInventory':
            $("#formIcon").text("Inventory page");
            itmList.css('display', 'none');
            itmMain.css('display', 'block');
            inventoryPage.css('display', 'block');
            allCaptureClear();
            break;
        case 'btnSupplier':
            $("#formIcon").text("Supplier page");
            supList.css('display', 'none');
            supMain.css('display', 'block');
            supplierPage.css('display', 'block');
            allCaptureClear();
            break;
        case 'btnEmployee':
            $("#formIcon").text("Employee page");
            empList.css('display', 'none');
            empMain.css('display', 'block');
            employeePage.css('display', 'block');
            allCaptureClear();
            break;
        case 'btnAdminPanel':
            $("#formIcon").text("Admin page");
            adminEditPage.css('display', 'block');
            getAllAdmins();
            allCaptureClear();
            break;
        case 'btnSales':
            $("#formIcon").text("Sales page");
            paymentPage.css('display', 'block');
            allCaptureClear();
            break;
        case 'btnUsers':
            $("#formIcon").text("Users page");
            userEditPage.css('display', 'block');
            getAllUsers();
            allCaptureClear();
            break;
        case 'btnDashboard':
            $("#formIcon").text("Admin Panel");
            adminDashboard.css('display', 'block');
            setAdminPanel();
            allCaptureClear();
            break;
    }
});
function allCaptureClear() {
    if (videoStream) {
        stopWebcamStream();
        $('#cusVideo').hide();
        captureClear();
    }else if (empVideoStream) {
        empCaptureClear();
    }else if (itmVideoStream) {
        itmCaptureClear();
    }
}

$("#side-bar-icon").click(function () {
    /*var navBarWidth = parseFloat($("#nav-bar").css('width'));
    if (Math.abs(navBarWidth - 5) < 0.01) {
        console.log("nav")
        $("#nav-bar").css('width', "20%");
        $("#nav-bar").css("transition", "all 0.3s ease");
    }*/
});